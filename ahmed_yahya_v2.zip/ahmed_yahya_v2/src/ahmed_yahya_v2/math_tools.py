def add(a: int, b: int) -> int:
    """جمع رقمين"""
    return a + b

def subtract(a: int, b: int) -> int:
    """طرح رقمين"""
    return a - b

def multiply(a: int, b: int) -> int:
    """ضرب رقمين"""
    return a * b

def divide(a: int, b: int) -> float:
    """قسمة رقمين مع معالجة القسمة على صفر"""
    if b == 0:
        raise ValueError("لا يمكن القسمة على صفر")
    return a / b
