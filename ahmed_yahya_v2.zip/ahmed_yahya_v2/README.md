# Ahmed Yahya Package v2

نسخة ثانية من مكتبة العمليات الرياضية، لإجراء تجارب على TestPyPI.

## التثبيت

```bash
pip install ahmed_yahya_v2
```

## الاستخدام

```python
from ahmed_yahya_v2 import add, subtract, multiply, divide

print(add(3, 2))       # 5
print(subtract(5, 2))  # 3
print(multiply(4, 3))  # 12
print(divide(10, 2))   # 5.0
```
